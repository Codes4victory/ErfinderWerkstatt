import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Lightbulb, Plus, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PostCard } from "@/components/post-card";
import { CreatePostModal } from "@/components/create-post-modal";
import { PostDetailModal } from "@/components/post-detail-modal";
import { SidebarFilters } from "@/components/sidebar-filters";
import { type Post } from "@shared/schema";

export default function Home() {
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [filters, setFilters] = useState({
    type: "all",
    search: "",
    postalCode: "",
  });

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["/api/posts", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.type !== "all") params.append("type", filters.type);
      if (filters.search) params.append("search", filters.search);
      if (filters.postalCode) params.append("postalCode", filters.postalCode);
      
      const response = await fetch(`/api/posts?${params}`);
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json() as Promise<Post[]>;
    },
  });

  const stats = {
    ideas: posts.filter(p => p.type === "offer").length,
    questions: posts.filter(p => p.type === "question").length,
    jobs: posts.filter(p => p.type === "job").length,
  };

  return (
    <div className="font-inter bg-slate-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <Lightbulb className="text-primary text-2xl mr-3" />
                <h1 className="text-xl font-bold text-slate-900">InnoConnect</h1>
              </div>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-slate-600 hover:text-slate-900 px-3 py-2 text-sm font-medium">Durchsuchen</a>
              <a href="#" className="text-slate-600 hover:text-slate-900 px-3 py-2 text-sm font-medium">Meine Beiträge</a>
              <a href="#" className="text-slate-600 hover:text-slate-900 px-3 py-2 text-sm font-medium">Hilfe</a>
            </nav>

            <div className="flex items-center space-x-4">
              <Button 
                onClick={() => setCreateModalOpen(true)}
                className="bg-primary text-white hover:bg-blue-700"
                data-testid="button-new-post"
              >
                <Plus className="w-4 h-4 mr-2" />
                Neuer Beitrag
              </Button>
              <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center">
                <User className="text-slate-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <SidebarFilters filters={filters} onFiltersChange={setFilters} />
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Hero Section */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-8">
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-2/3 mb-6 md:mb-0">
                  <h2 className="text-3xl font-bold text-slate-900 mb-4">Vernetzen. Zusammenarbeiten. Erschaffen.</h2>
                  <p className="text-lg text-slate-600 mb-6">Ein Ort, an dem Privatpersonen, Fachleute und Unternehmen zusammenkommen, um Ideen zu teilen, Fragen zu stellen und Möglichkeiten zu posten.</p>
                  <div className="flex flex-wrap gap-4">
                    <div className="flex items-center text-sm text-slate-600">
                      <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                      <span className="font-medium">[Idee Anbieten]</span> für Erfindungen & Lösungen
                    </div>
                    <div className="flex items-center text-sm text-slate-600">
                      <span className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
                      <span className="font-medium">[Frage Stellen]</span> für technische Herausforderungen
                    </div>
                    <div className="flex items-center text-sm text-slate-600">
                      <span className="w-3 h-3 bg-purple-500 rounded-full mr-2"></span>
                      <span className="font-medium">[Job Posten]</span> für Produktion & Entwicklung
                    </div>
                  </div>
                </div>
                <div className="md:w-1/3">
                  <img 
                    src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                    alt="Collaborative workspace with professionals working together" 
                    className="rounded-xl shadow-lg w-full h-auto"
                  />
                </div>
              </div>
            </div>

            {/* Stats Bar */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 text-center">
                <div className="text-2xl font-bold text-green-500" data-testid="text-ideas-count">{stats.ideas}</div>
                <div className="text-sm text-slate-600">Geteilte Ideen</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 text-center">
                <div className="text-2xl font-bold text-yellow-500" data-testid="text-questions-count">{stats.questions}</div>
                <div className="text-sm text-slate-600">Gestellte Fragen</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 text-center">
                <div className="text-2xl font-bold text-purple-500" data-testid="text-jobs-count">{stats.jobs}</div>
                <div className="text-sm text-slate-600">Gepostete Jobs</div>
              </div>
            </div>

            {/* Posts Feed */}
            <div className="space-y-6">
              {isLoading ? (
                <div className="text-center py-8">Lade Beiträge...</div>
              ) : posts.length === 0 ? (
                <div className="text-center py-8 text-slate-600">
                  Keine Beiträge gefunden, die Ihren Filtern entsprechen.
                </div>
              ) : (
                posts.map((post) => (
                  <PostCard 
                    key={post.id} 
                    post={post} 
                    onClick={() => setSelectedPost(post)}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      <CreatePostModal 
        open={createModalOpen} 
        onOpenChange={setCreateModalOpen} 
      />
      
      <PostDetailModal 
        post={selectedPost} 
        open={!!selectedPost} 
        onOpenChange={(open: boolean) => !open && setSelectedPost(null)} 
      />
    </div>
  );
}
