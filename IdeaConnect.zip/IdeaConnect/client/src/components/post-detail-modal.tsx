import { formatDistanceToNow } from "date-fns";
import { X, Lightbulb, HelpCircle, Briefcase, MapPin, Mail, Bookmark } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { type Post } from "@shared/schema";

interface PostDetailModalProps {
  post: Post | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PostDetailModal({ post, open, onOpenChange }: PostDetailModalProps) {
  if (!post) return null;

  const getPostIcon = () => {
    switch (post.type) {
      case "offer":
        return <Lightbulb className="text-white" />;
      case "question":
        return <HelpCircle className="text-white" />;
      case "job":
        return <Briefcase className="text-white" />;
    }
  };

  const getPostBadge = () => {
    switch (post.type) {
      case "offer":
        return <span className="bg-green-500 text-white px-2 py-1 rounded text-xs font-medium">[Idee Anbieten]</span>;
      case "question":
        return <span className="bg-yellow-500 text-white px-2 py-1 rounded text-xs font-medium">[Frage Stellen]</span>;
      case "job":
        return <span className="bg-purple-500 text-white px-2 py-1 rounded text-xs font-medium">[Job Posten]</span>;
    }
  };

  const getIconBgColor = () => {
    switch (post.type) {
      case "offer":
        return "bg-green-500";
      case "question":
        return "bg-yellow-500";
      case "job":
        return "bg-purple-500";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-post-detail">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-3">
              <div className={`w-12 h-12 ${getIconBgColor()} rounded-full flex items-center justify-center`}>
                {getPostIcon()}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  {getPostBadge()}
                  <span className="text-sm text-slate-500">•</span>
                  <span className="text-sm text-slate-500">
                    {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-slate-900 mt-1" data-testid="text-detail-title">
                  {post.title}
                </h2>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onOpenChange(false)}
              data-testid="button-close-detail"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="prose max-w-none">
                <p className="text-lg text-slate-600 mb-6" data-testid="text-detail-description">
                  {post.description}
                </p>
                
                {post.type === "offer" && (
                  <>
                    <h3 className="text-xl font-semibold text-slate-900 mb-3">Was ich suche:</h3>
                    <p className="text-slate-600 mb-6">
                      Ich suche Partner, Investoren oder Mitarbeiter, die an dieser Lösung interessiert sind. 
                      Zögern Sie nicht, sich zu melden, wenn Sie mehr erfahren oder mögliche Chancen besprechen möchten.
                    </p>
                  </>
                )}

                {post.type === "question" && (
                  <>
                    <h3 className="text-xl font-semibold text-slate-900 mb-3">Zusätzlicher Kontext:</h3>
                    <p className="text-slate-600 mb-6">
                      Jeder Rat, Empfehlungen oder Kontakte wären sehr willkommen. 
                      Gerne gebe ich weitere Details zu den spezifischen Anforderungen.
                    </p>
                  </>
                )}

                {post.type === "job" && (
                  <>
                    <h3 className="text-xl font-semibold text-slate-900 mb-3">Anforderungen:</h3>
                    <p className="text-slate-600 mb-6">
                      Suche erfahrene Fachkräfte mit relevanten Fähigkeiten und Portfolio. 
                      Wettbewerbsfähige Vergütung und Möglichkeit zur langfristigen Zusammenarbeit.
                    </p>
                  </>
                )}
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-slate-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Kontaktinformationen</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-slate-300 rounded-full flex items-center justify-center">
                      <span className="text-slate-600 font-medium">
                        {post.authorName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <div className="font-medium text-slate-900" data-testid="text-detail-author">
                        {post.authorName}
                      </div>
                      <div className="text-sm text-slate-600">
                        {post.type === "offer" ? "Erfinder & Innovator" : 
                         post.type === "question" ? "Problemlöser" : "Personalmanager"}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center text-sm text-slate-600">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span data-testid="text-detail-location">{post.postalCode}</span>
                  </div>
                  
                  {post.tags && (
                    <div className="flex items-center text-sm text-slate-600">
                      <span className="mr-2">#</span>
                      <span data-testid="text-detail-tags">{post.tags}</span>
                    </div>
                  )}
                </div>

                <div className="mt-6 space-y-3">
                  <Button className="w-full" data-testid="button-contact-author">
                    <Mail className="w-4 h-4 mr-2" />
                    Autor kontaktieren
                  </Button>
                  <Button variant="outline" className="w-full" data-testid="button-save-post">
                    <Bookmark className="w-4 h-4 mr-2" />
                    Beitrag speichern
                  </Button>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="text-md font-semibold text-slate-900 mb-3">Ähnliche Beiträge</h4>
                <div className="space-y-3">
                  <div className="bg-white border border-slate-200 rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer">
                    <div className="text-sm font-medium text-slate-900 mb-1">Intelligentes Energiemanagementsystem</div>
                    <div className="text-xs text-slate-500">10115 • vor 1 Tag</div>
                  </div>
                  <div className="bg-white border border-slate-200 rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer">
                    <div className="text-sm font-medium text-slate-900 mb-1">GreenTech-Fertigungspartnerschaft</div>
                    <div className="text-xs text-slate-500">20095 • vor 3 Tagen</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
