import { formatDistanceToNow } from "date-fns";
import { Lightbulb, HelpCircle, Briefcase, MapPin, Heart, Bookmark, Share } from "lucide-react";
import { type Post } from "@shared/schema";
import { Button } from "@/components/ui/button";

interface PostCardProps {
  post: Post;
  onClick: () => void;
}

export function PostCard({ post, onClick }: PostCardProps) {
  const getPostIcon = () => {
    switch (post.type) {
      case "offer":
        return <Lightbulb className="text-white" />;
      case "question":
        return <HelpCircle className="text-white" />;
      case "job":
        return <Briefcase className="text-white" />;
    }
  };

  const getPostBadge = () => {
    switch (post.type) {
      case "offer":
        return <span className="bg-green-500 text-white px-2 py-1 rounded text-xs font-medium">[Idee Anbieten]</span>;
      case "question":
        return <span className="bg-yellow-500 text-white px-2 py-1 rounded text-xs font-medium">[Frage Stellen]</span>;
      case "job":
        return <span className="bg-purple-500 text-white px-2 py-1 rounded text-xs font-medium">[Job Posten]</span>;
    }
  };

  const getIconBgColor = () => {
    switch (post.type) {
      case "offer":
        return "bg-green-500";
      case "question":
        return "bg-yellow-500";
      case "job":
        return "bg-purple-500";
    }
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
      data-testid={`card-post-${post.id}`}
    >
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${getIconBgColor()} rounded-full flex items-center justify-center`}>
              {getPostIcon()}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                {getPostBadge()}
                <span className="text-sm text-slate-500">•</span>
                <span className="text-sm text-slate-500">
                  {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mt-1" data-testid={`text-title-${post.id}`}>
                {post.title}
              </h3>
            </div>
          </div>
          <div className="flex items-center text-sm text-slate-500">
            <MapPin className="w-4 h-4 mr-1" />
            <span data-testid={`text-location-${post.id}`}>{post.postalCode}</span>
          </div>
        </div>
        
        <p className="text-slate-600 mb-4" data-testid={`text-description-${post.id}`}>
          {post.description.length > 200 
            ? `${post.description.substring(0, 200)}...` 
            : post.description
          }
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center text-sm text-slate-500">
              <div className="w-6 h-6 bg-slate-300 rounded-full mr-2"></div>
              <span data-testid={`text-author-${post.id}`}>{post.authorName}</span>
            </div>
            {post.tags && (
              <div className="flex items-center text-sm text-slate-500">
                <span className="mr-1">#</span>
                <span data-testid={`text-tags-${post.id}`}>{post.tags}</span>
              </div>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" data-testid={`button-like-${post.id}`}>
              <Heart className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" data-testid={`button-bookmark-${post.id}`}>
              <Bookmark className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" data-testid={`button-share-${post.id}`}>
              <Share className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
