import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface FiltersState {
  type: string;
  search: string;
  postalCode: string;
}

interface SidebarFiltersProps {
  filters: FiltersState;
  onFiltersChange: (filters: FiltersState) => void;
}

export function SidebarFilters({ filters, onFiltersChange }: SidebarFiltersProps) {
  const updateFilter = (key: keyof FiltersState, value: string) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sticky top-8">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">Filter</h3>
      
      {/* Search */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-slate-700 mb-2">Suchen</Label>
        <div className="relative">
          <Input 
            type="text" 
            placeholder="Beiträge suchen..." 
            value={filters.search}
            onChange={(e) => updateFilter("search", e.target.value)}
            className="pl-10"
            data-testid="input-search"
          />
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
        </div>
      </div>

      {/* Post Type Filter */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-slate-700 mb-3">Beitragstyp</Label>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="all-types" 
              checked={filters.type === "all"}
              onCheckedChange={() => updateFilter("type", "all")}
              data-testid="checkbox-all-types"
            />
            <Label htmlFor="all-types" className="text-sm text-slate-600">Alle Typen</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="offer-type" 
              checked={filters.type === "offer"}
              onCheckedChange={() => updateFilter("type", "offer")}
              data-testid="checkbox-offer-type"
            />
            <Label htmlFor="offer-type" className="text-sm text-slate-600 flex items-center">
              <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
              Ideen anbieten
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="question-type" 
              checked={filters.type === "question"}
              onCheckedChange={() => updateFilter("type", "question")}
              data-testid="checkbox-question-type"
            />
            <Label htmlFor="question-type" className="text-sm text-slate-600 flex items-center">
              <span className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
              Fragen stellen
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="job-type" 
              checked={filters.type === "job"}
              onCheckedChange={() => updateFilter("type", "job")}
              data-testid="checkbox-job-type"
            />
            <Label htmlFor="job-type" className="text-sm text-slate-600 flex items-center">
              <span className="w-3 h-3 bg-purple-500 rounded-full mr-2"></span>
              Jobs posten
            </Label>
          </div>
        </div>
      </div>

      {/* Location Filter */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-slate-700 mb-2">Standortfilter</Label>
        <Input 
          type="text" 
          placeholder="Postleitzahl eingeben..." 
          value={filters.postalCode}
          onChange={(e) => updateFilter("postalCode", e.target.value)}
          data-testid="input-location-filter"
        />
        <p className="text-xs text-slate-500 mt-1">Nach Nähe zur Postleitzahl filtern</p>
      </div>

      {/* Location Range */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-slate-700 mb-2">Standortbereich</Label>
        <Select defaultValue="10">
          <SelectTrigger data-testid="select-location-range">
            <SelectValue placeholder="Bereich auswählen" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="10">Innerhalb 15 km</SelectItem>
            <SelectItem value="25">Innerhalb 40 km</SelectItem>
            <SelectItem value="50">Innerhalb 80 km</SelectItem>
            <SelectItem value="100">Innerhalb 160 km</SelectItem>
            <SelectItem value="nationwide">Deutschlandweit</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Sort Options */}
      <div>
        <Label className="block text-sm font-medium text-slate-700 mb-2">Sortieren nach</Label>
        <Select defaultValue="recent">
          <SelectTrigger data-testid="select-sort-by">
            <SelectValue placeholder="Sortieren nach" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="recent">Neueste zuerst</SelectItem>
            <SelectItem value="relevant">Relevanteste zuerst</SelectItem>
            <SelectItem value="nearest">Nächster Standort</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
