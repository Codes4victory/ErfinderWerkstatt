import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Lightbulb, HelpCircle, Briefcase, CloudUpload } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { insertPostSchema, type InsertPost } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface CreatePostModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreatePostModal({ open, onOpenChange }: CreatePostModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertPost>({
    resolver: zodResolver(insertPostSchema),
    defaultValues: {
      type: "offer",
      title: "",
      description: "",
      authorName: "",
      postalCode: "",
      tags: "",
    },
  });

  const createPostMutation = useMutation({
    mutationFn: async (data: InsertPost) => {
      const response = await apiRequest("POST", "/api/posts", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Erfolgreich",
        description: "Ihr Beitrag wurde erfolgreich erstellt!",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Fehler",
        description: "Beitrag konnte nicht erstellt werden. Bitte versuchen Sie es erneut.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertPost) => {
    createPostMutation.mutate(data);
  };

  const getFullTitle = (type: string, title: string) => {
    const prefix = type === "offer" ? "[Idee Anbieten]" : 
                  type === "question" ? "[Frage Stellen]" : "[Job Posten]";
    return title ? `${prefix} ${title}` : prefix;
  };

  const watchedType = form.watch("type");
  const watchedTitle = form.watch("title");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="modal-create-post">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-900">Neuen Beitrag erstellen</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Post Type Selection */}
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-slate-700">Beitragstyp *</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="grid grid-cols-1 gap-3"
                    >
                      <div className="flex items-center p-4 border border-slate-300 rounded-lg hover:bg-slate-50">
                        <RadioGroupItem value="offer" id="offer" className="text-green-500" data-testid="radio-offer" />
                        <Label htmlFor="offer" className="ml-3 flex items-center cursor-pointer">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-3">
                            <Lightbulb className="text-white" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">[Idee Anbieten]</div>
                            <div className="text-sm text-slate-600">Teilen Sie Erfindungen, Verbesserungen oder kreative Lösungen</div>
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center p-4 border border-slate-300 rounded-lg hover:bg-slate-50">
                        <RadioGroupItem value="question" id="question" className="text-yellow-500" data-testid="radio-question" />
                        <Label htmlFor="question" className="ml-3 flex items-center cursor-pointer">
                          <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center mr-3">
                            <HelpCircle className="text-white" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">[Frage Stellen]</div>
                            <div className="text-sm text-slate-600">Erhalten Sie Hilfe bei technischen oder handwerklichen Herausforderungen</div>
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center p-4 border border-slate-300 rounded-lg hover:bg-slate-50">
                        <RadioGroupItem value="job" id="job" className="text-purple-500" data-testid="radio-job" />
                        <Label htmlFor="job" className="ml-3 flex items-center cursor-pointer">
                          <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                            <Briefcase className="text-white" />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">[Job Posten]</div>
                            <div className="text-sm text-slate-600">Finden Sie jemanden für Fertigung, Design oder Beratung</div>
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Title Preview */}
            <div className="p-3 bg-slate-50 rounded-lg border">
              <Label className="text-sm font-medium text-slate-700">Vorschau:</Label>
              <p className="text-slate-900 font-medium" data-testid="text-title-preview">
                {getFullTitle(watchedType, watchedTitle)}
              </p>
            </div>

            {/* Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Titel *</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Ihre Überschrift wird automatisch basierend auf dem Beitragstyp vorangestellt" 
                      {...field}
                      data-testid="input-title"
                    />
                  </FormControl>
                  <p className="text-sm text-slate-500">Beispiel: "Revolutionäres Solaranlagen-Reinigungssystem"</p>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Beschreibung *</FormLabel>
                  <FormControl>
                    <Textarea 
                      rows={6}
                      placeholder="Geben Sie detaillierte Informationen zu Ihrer Idee, Frage oder Stellenausschreibung an..." 
                      className="resize-none"
                      {...field}
                      data-testid="textarea-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Contact Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="authorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ihr Name *</FormLabel>
                    <FormControl>
                      <Input placeholder="Max Mustermann" {...field} data-testid="input-author-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="postalCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Postleitzahl *</FormLabel>
                    <FormControl>
                      <Input placeholder="10115" {...field} data-testid="input-postal-code" />
                    </FormControl>
                    <p className="text-sm text-slate-500">Hilft anderen, lokale Möglichkeiten zu finden</p>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Tags */}
            <FormField
              control={form.control}
              name="tags"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tags</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="solar, cleantech, innovation (durch Kommas getrennt)" 
                      {...field} 
                      data-testid="input-tags"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Image Upload Placeholder */}
            <div>
              <Label className="block text-sm font-medium text-slate-700 mb-2">Bilder (Optional)</Label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-slate-400 transition-colors cursor-pointer">
                <CloudUpload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <div className="text-slate-600">Klicken Sie zum Hochladen von Bildern oder ziehen Sie sie hierher</div>
                <div className="text-sm text-slate-500 mt-1">PNG, JPG bis zu 10MB</div>
              </div>
            </div>

            {/* Form Actions */}
            <div className="flex justify-end space-x-4 pt-6 border-t border-slate-200">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel"
              >
                Abbrechen
              </Button>
              <Button 
                type="submit" 
                disabled={createPostMutation.isPending}
                data-testid="button-publish"
              >
                {createPostMutation.isPending ? "Wird veröffentlicht..." : "Beitrag veröffentlichen"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
