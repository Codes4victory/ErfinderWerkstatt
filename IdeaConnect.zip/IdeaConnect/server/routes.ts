import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPostSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all posts with optional filters
  app.get("/api/posts", async (req, res) => {
    try {
      const { type, search, postalCode } = req.query;
      const posts = await storage.getPosts({
        type: type as string,
        search: search as string,
        postalCode: postalCode as string,
      });
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Beiträge" });
    }
  });

  // Get single post by ID
  app.get("/api/posts/:id", async (req, res) => {
    try {
      const post = await storage.getPost(req.params.id);
      if (!post) {
        return res.status(404).json({ message: "Beitrag nicht gefunden" });
      }
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden des Beitrags" });
    }
  });

  // Create new post
  app.post("/api/posts", async (req, res) => {
    try {
      const validatedData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validierungsfehler", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Fehler beim Erstellen des Beitrags" });
    }
  });

  // Update post
  app.put("/api/posts/:id", async (req, res) => {
    try {
      const validatedData = insertPostSchema.partial().parse(req.body);
      const post = await storage.updatePost(req.params.id, validatedData);
      if (!post) {
        return res.status(404).json({ message: "Beitrag nicht gefunden" });
      }
      res.json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validierungsfehler", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Fehler beim Aktualisieren des Beitrags" });
    }
  });

  // Delete post
  app.delete("/api/posts/:id", async (req, res) => {
    try {
      const success = await storage.deletePost(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Beitrag nicht gefunden" });
      }
      res.json({ message: "Beitrag erfolgreich gelöscht" });
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Löschen des Beitrags" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
