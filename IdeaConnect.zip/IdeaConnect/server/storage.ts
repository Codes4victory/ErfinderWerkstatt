import { type Post, type InsertPost } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getPosts(filters?: { type?: string; search?: string; postalCode?: string }): Promise<Post[]>;
  getPost(id: string): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, post: Partial<InsertPost>): Promise<Post | undefined>;
  deletePost(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private posts: Map<string, Post>;

  constructor() {
    this.posts = new Map();
    
    // Beispielposts für die Demonstration
    const samplePosts: Post[] = [
      {
        id: "1",
        type: "offer",
        title: "Revolutionäres Solaranlagen-Reinigungssystem",
        description: "Ich habe ein automatisiertes Reinigungssystem für Solaranlagen entwickelt, das die Effizienz um 23% steigert. Suche Fertigungspartner oder Investoren, die an nachhaltigen Energielösungen interessiert sind.",
        authorName: "Michael Schmidt",
        postalCode: "10115",
        tags: "CleanTech, Solar, Innovation",
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // vor 2 Stunden
      },
      {
        id: "2",
        type: "question",
        title: "Benötige Rat zur Wasserdichtung von Elektronik für maritime Anwendungen",
        description: "Ich entwickle ein Navigationsgerät für Boote und benötige Empfehlungen für wasserdichte Lösungen, die Salzwasserexposition widerstehen können. Gibt es hier Experten für Schiffselektronik?",
        authorName: "Sarah Müller",
        postalCode: "20095",
        tags: "Elektronik, Marine, Wasserdichtung",
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // vor 4 Stunden
      },
      {
        id: "3",
        type: "job",
        title: "Suche 3D-Druck-Spezialisten für individuelle Möbelprototypen",
        description: "Designstudio sucht erfahrenen 3D-Druck-Spezialisten zur Erstellung von Prototypen für modulare Möbellinie. Erfahrung mit großformatigem Druck und verschiedenen Materialien erforderlich. Projektdauer: 3-4 Monate.",
        authorName: "Emma Weber",
        postalCode: "80331",
        tags: "3D-Druck, Möbel, Design",
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // vor 6 Stunden
      },
      {
        id: "4",
        type: "offer",
        title: "Intelligentes Urban-Gardening-System für Wohnungen",
        description: "Habe ein hydroponisches System entwickelt, das auf Wohnungsbalkone passt und automatische Nährstoffversorgung mit App-Überwachung bietet. Perfekt für Stadtbewohner, die frisches Gemüse anbauen möchten.",
        authorName: "David Klein",
        postalCode: "50667",
        tags: "Landwirtschaft, IoT, Nachhaltigkeit",
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // vor 1 Tag
      },
    ];

    samplePosts.forEach(post => this.posts.set(post.id, post));
  }

  async getPosts(filters?: { type?: string; search?: string; postalCode?: string }): Promise<Post[]> {
    let posts = Array.from(this.posts.values());

    if (filters?.type && filters.type !== "all") {
      posts = posts.filter(post => post.type === filters.type);
    }

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      posts = posts.filter(post => 
        post.title.toLowerCase().includes(searchLower) ||
        post.description.toLowerCase().includes(searchLower) ||
        post.tags?.toLowerCase().includes(searchLower)
      );
    }

    if (filters?.postalCode) {
      // Simple proximity filter - in a real app, you'd calculate distances
      posts = posts.filter(post => post.postalCode.startsWith(filters.postalCode!.substring(0, 3)));
    }

    // Sort by creation date, newest first
    return posts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getPost(id: string): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const post: Post = {
      ...insertPost,
      id,
      createdAt: new Date(),
      tags: insertPost.tags || null,
    };
    this.posts.set(id, post);
    return post;
  }

  async updatePost(id: string, updateData: Partial<InsertPost>): Promise<Post | undefined> {
    const existingPost = this.posts.get(id);
    if (!existingPost) return undefined;

    const updatedPost: Post = {
      ...existingPost,
      ...updateData,
    };
    this.posts.set(id, updatedPost);
    return updatedPost;
  }

  async deletePost(id: string): Promise<boolean> {
    return this.posts.delete(id);
  }
}

export const storage = new MemStorage();
